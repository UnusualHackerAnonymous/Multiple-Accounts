package android.support.p002a.p003a;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: android.support.a.a.a */
/* compiled from: ITrustedWebActivityCallback */
public interface C0004a extends IInterface {
    void onExtraCallback(String str, Bundle bundle) throws RemoteException;

    /* renamed from: android.support.a.a.a$a */
    /* compiled from: ITrustedWebActivityCallback */
    public static abstract class C0005a extends Binder implements C0004a {
        private static final String DESCRIPTOR = "android.support.customtabs.trusted.ITrustedWebActivityCallback";
        static final int TRANSACTION_onExtraCallback = 2;

        public IBinder asBinder() {
            return this;
        }

        public C0005a() {
            attachInterface(this, DESCRIPTOR);
        }

        public static C0004a asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(DESCRIPTOR);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof C0004a)) {
                return new C0006a(iBinder);
            }
            return (C0004a) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i == 2) {
                parcel.enforceInterface(DESCRIPTOR);
                onExtraCallback(parcel.readString(), parcel.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(parcel) : null);
                parcel2.writeNoException();
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString(DESCRIPTOR);
                return true;
            }
        }

        /* renamed from: android.support.a.a.a$a$a */
        /* compiled from: ITrustedWebActivityCallback */
        private static class C0006a implements C0004a {

            /* renamed from: a */
            public static C0004a f2a;

            /* renamed from: b */
            private IBinder f3b;

            C0006a(IBinder iBinder) {
                this.f3b = iBinder;
            }

            public IBinder asBinder() {
                return this.f3b;
            }

            public void onExtraCallback(String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(C0005a.DESCRIPTOR);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (this.f3b.transact(2, obtain, obtain2, 0) || C0005a.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    C0005a.getDefaultImpl().onExtraCallback(str, bundle);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static boolean setDefaultImpl(C0004a aVar) {
            if (C0006a.f2a != null) {
                throw new IllegalStateException("setDefaultImpl() called twice");
            } else if (aVar == null) {
                return false;
            } else {
                C0006a.f2a = aVar;
                return true;
            }
        }

        public static C0004a getDefaultImpl() {
            return C0006a.f2a;
        }
    }
}
