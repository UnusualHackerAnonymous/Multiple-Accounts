package androidx.browser.trusted;

import androidx.concurrent.futures.ResolvableFuture;
import com.google.p193a.p194a.p195a.C4576a;

class FutureUtils {
    static <T> C4576a<T> immediateFailedFuture(Throwable th) {
        ResolvableFuture create = ResolvableFuture.create();
        create.setException(th);
        return create;
    }

    private FutureUtils() {
    }
}
