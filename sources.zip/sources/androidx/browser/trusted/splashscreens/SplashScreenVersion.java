package androidx.browser.trusted.splashscreens;

public final class SplashScreenVersion {

    /* renamed from: V1 */
    public static final String f28V1 = "androidx.browser.trusted.category.TrustedWebActivitySplashScreensV1";

    private SplashScreenVersion() {
    }
}
