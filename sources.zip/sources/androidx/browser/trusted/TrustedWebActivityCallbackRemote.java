package androidx.browser.trusted;

import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.p002a.p003a.C0004a;

public class TrustedWebActivityCallbackRemote {
    private final C0004a mCallbackBinder;

    private TrustedWebActivityCallbackRemote(C0004a aVar) {
        this.mCallbackBinder = aVar;
    }

    static TrustedWebActivityCallbackRemote fromBinder(IBinder iBinder) {
        C0004a asInterface = iBinder == null ? null : C0004a.C0005a.asInterface(iBinder);
        if (asInterface == null) {
            return null;
        }
        return new TrustedWebActivityCallbackRemote(asInterface);
    }

    public void runExtraCallback(String str, Bundle bundle) throws RemoteException {
        this.mCallbackBinder.onExtraCallback(str, bundle);
    }
}
