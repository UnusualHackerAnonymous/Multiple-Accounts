package androidx.browser.customtabs;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.p002a.C0001a;
import android.support.p002a.C0013c;

public class PostMessageService extends Service {
    private C0013c.C0014a mBinder = new C0013c.C0014a() {
        public void onMessageChannelReady(C0001a aVar, Bundle bundle) throws RemoteException {
            aVar.onMessageChannelReady(bundle);
        }

        public void onPostMessage(C0001a aVar, String str, Bundle bundle) throws RemoteException {
            aVar.onPostMessage(str, bundle);
        }
    };

    public IBinder onBind(Intent intent) {
        return this.mBinder;
    }
}
