package androidx.browser;

/* renamed from: androidx.browser.R */
public final class C0165R {

    /* renamed from: androidx.browser.R$color */
    public static final class color {
        public static final int browser_actions_bg_grey = 2131099758;
        public static final int browser_actions_divider_color = 2131099759;
        public static final int browser_actions_text_color = 2131099760;
        public static final int browser_actions_title_color = 2131099761;

        private color() {
        }
    }

    /* renamed from: androidx.browser.R$dimen */
    public static final class dimen {
        public static final int browser_actions_context_menu_max_width = 2131165373;
        public static final int browser_actions_context_menu_min_padding = 2131165374;

        private dimen() {
        }
    }

    /* renamed from: androidx.browser.R$id */
    public static final class C0166id {
        public static final int browser_actions_header_text = 2131362034;
        public static final int browser_actions_menu_item_icon = 2131362035;
        public static final int browser_actions_menu_item_text = 2131362036;
        public static final int browser_actions_menu_items = 2131362037;
        public static final int browser_actions_menu_view = 2131362038;

        private C0166id() {
        }
    }

    /* renamed from: androidx.browser.R$layout */
    public static final class layout {
        public static final int browser_actions_context_menu_page = 2131558481;
        public static final int browser_actions_context_menu_row = 2131558482;

        private layout() {
        }
    }

    /* renamed from: androidx.browser.R$string */
    public static final class string {
        public static final int copy_toast_msg = 2131820761;
        public static final int fallback_menu_item_copy_link = 2131820859;
        public static final int fallback_menu_item_open_in_browser = 2131820860;
        public static final int fallback_menu_item_share_link = 2131820861;

        private string() {
        }
    }

    /* renamed from: androidx.browser.R$xml */
    public static final class xml {
        public static final int image_share_filepaths = 2132017153;

        private xml() {
        }
    }

    private C0165R() {
    }
}
