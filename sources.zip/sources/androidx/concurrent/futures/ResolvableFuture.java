package androidx.concurrent.futures;

import com.google.p193a.p194a.p195a.C4576a;

public final class ResolvableFuture<V> extends AbstractResolvableFuture<V> {
    public static <V> ResolvableFuture<V> create() {
        return new ResolvableFuture<>();
    }

    public boolean set(V v) {
        return super.set(v);
    }

    public boolean setException(Throwable th) {
        return super.setException(th);
    }

    public boolean setFuture(C4576a<? extends V> aVar) {
        return super.setFuture(aVar);
    }

    private ResolvableFuture() {
    }
}
