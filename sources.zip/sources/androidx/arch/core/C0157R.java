package androidx.arch.core;

/* renamed from: androidx.arch.core.R */
public final class C0157R {
    private C0157R() {
    }
}
