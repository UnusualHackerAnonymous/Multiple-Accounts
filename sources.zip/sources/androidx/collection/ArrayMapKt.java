package androidx.collection;

import kotlin.C12331n;
import kotlin.Metadata;
import kotlin.jvm.internal.C12318m;

@Metadata(mo62563bv = {1, 0, 3}, mo62564d1 = {"\u0000\u0016\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a!\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003H\b\u001aO\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032*\u0010\u0004\u001a\u0016\u0012\u0012\b\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u00060\u0005\"\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0006¢\u0006\u0002\u0010\u0007¨\u0006\b"}, mo62565d2 = {"arrayMapOf", "Landroidx/collection/ArrayMap;", "K", "V", "pairs", "", "Lkotlin/Pair;", "([Lkotlin/Pair;)Landroidx/collection/ArrayMap;", "collection-ktx"}, mo62566k = 2, mo62567mv = {1, 1, 13})
/* compiled from: ArrayMap.kt */
public final class ArrayMapKt {
    public static final <K, V> ArrayMap<K, V> arrayMapOf() {
        return new ArrayMap<>();
    }

    public static final <K, V> ArrayMap<K, V> arrayMapOf(C12331n<? extends K, ? extends V>... nVarArr) {
        C12318m.m42358c(nVarArr, "pairs");
        ArrayMap<K, V> arrayMap = new ArrayMap<>(nVarArr.length);
        for (C12331n<? extends K, ? extends V> nVar : nVarArr) {
            arrayMap.put(nVar.mo62896a(), nVar.mo62897b());
        }
        return arrayMap;
    }
}
