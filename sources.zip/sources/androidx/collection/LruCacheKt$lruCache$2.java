package androidx.collection;

import kotlin.Metadata;
import kotlin.jvm.internal.C12318m;
import kotlin.jvm.internal.C12319n;
import kotlin.jvm.p580a.C12276b;

@Metadata(mo62563bv = {1, 0, 3}, mo62564d1 = {"\u0000\f\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0003\u0010\u0000\u001a\u0004\u0018\u0001H\u0001\"\b\b\u0000\u0010\u0002*\u00020\u0003\"\b\b\u0001\u0010\u0001*\u00020\u00032\u0006\u0010\u0004\u001a\u0002H\u0002H\n¢\u0006\u0004\b\u0005\u0010\u0006"}, mo62565d2 = {"<anonymous>", "V", "K", "", "it", "invoke", "(Ljava/lang/Object;)Ljava/lang/Object;"}, mo62566k = 3, mo62567mv = {1, 1, 13})
/* compiled from: LruCache.kt */
public final class LruCacheKt$lruCache$2 extends C12319n implements C12276b<K, V> {
    public static final LruCacheKt$lruCache$2 INSTANCE = new LruCacheKt$lruCache$2();

    public LruCacheKt$lruCache$2() {
        super(1);
    }

    public final V invoke(K k) {
        C12318m.m42358c(k, "it");
        return null;
    }
}
