package androidx.collection;

import com.google.android.gms.measurement.api.AppMeasurementSdk;
import kotlin.Metadata;
import kotlin.jvm.internal.C12318m;
import kotlin.jvm.p580a.C12276b;
import kotlin.jvm.p580a.C12287m;
import kotlin.jvm.p580a.C12292r;

@Metadata(mo62563bv = {1, 0, 3}, mo62564d1 = {"\u0000#\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010\u0001J\u0017\u0010\u0002\u001a\u0004\u0018\u00018\u00012\u0006\u0010\u0003\u001a\u00028\u0000H\u0014¢\u0006\u0002\u0010\u0004J/\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0003\u001a\u00028\u00002\u0006\u0010\t\u001a\u00028\u00012\b\u0010\n\u001a\u0004\u0018\u00018\u0001H\u0014¢\u0006\u0002\u0010\u000bJ\u001d\u0010\f\u001a\u00020\r2\u0006\u0010\u0003\u001a\u00028\u00002\u0006\u0010\u000e\u001a\u00028\u0001H\u0014¢\u0006\u0002\u0010\u000f¨\u0006\u0010"}, mo62565d2 = {"androidx/collection/LruCacheKt$lruCache$4", "Landroidx/collection/LruCache;", "create", "key", "(Ljava/lang/Object;)Ljava/lang/Object;", "entryRemoved", "", "evicted", "", "oldValue", "newValue", "(ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V", "sizeOf", "", "value", "(Ljava/lang/Object;Ljava/lang/Object;)I", "collection-ktx"}, mo62566k = 1, mo62567mv = {1, 1, 13})
/* compiled from: LruCache.kt */
public final class LruCacheKt$lruCache$4 extends LruCache<K, V> {
    final /* synthetic */ C12276b $create;
    final /* synthetic */ int $maxSize;
    final /* synthetic */ C12292r $onEntryRemoved;
    final /* synthetic */ C12287m $sizeOf;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LruCacheKt$lruCache$4(C12287m mVar, C12276b bVar, C12292r rVar, int i, int i2) {
        super(i2);
        this.$sizeOf = mVar;
        this.$create = bVar;
        this.$onEntryRemoved = rVar;
        this.$maxSize = i;
    }

    /* access modifiers changed from: protected */
    public int sizeOf(K k, V v) {
        C12318m.m42358c(k, "key");
        C12318m.m42358c(v, AppMeasurementSdk.ConditionalUserProperty.VALUE);
        return ((Number) this.$sizeOf.invoke(k, v)).intValue();
    }

    /* access modifiers changed from: protected */
    public V create(K k) {
        C12318m.m42358c(k, "key");
        return this.$create.invoke(k);
    }

    /* access modifiers changed from: protected */
    public void entryRemoved(boolean z, K k, V v, V v2) {
        C12318m.m42358c(k, "key");
        C12318m.m42358c(v, "oldValue");
        this.$onEntryRemoved.invoke(Boolean.valueOf(z), k, v, v2);
    }
}
