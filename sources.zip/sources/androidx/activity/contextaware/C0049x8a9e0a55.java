package androidx.activity.contextaware;

import android.content.Context;
import com.umeng.analytics.pro.C11319d;
import kotlin.C12332o;
import kotlin.C12335p;
import kotlin.Metadata;
import kotlin.jvm.internal.C12318m;
import kotlin.jvm.p580a.C12276b;
import kotlinx.coroutines.C12498k;

@Metadata(mo62563bv = {1, 0, 3}, mo62564d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0006¸\u0006\u0000"}, mo62565d2 = {"androidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1", "Landroidx/activity/contextaware/OnContextAvailableListener;", "onContextAvailable", "", "context", "Landroid/content/Context;", "activity-ktx_release"}, mo62566k = 1, mo62567mv = {1, 4, 1})
/* renamed from: androidx.activity.contextaware.ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 */
/* compiled from: ContextAware.kt */
public final class C0049x8a9e0a55 implements OnContextAvailableListener {
    final /* synthetic */ C12498k $co;
    final /* synthetic */ C12276b $onContextAvailable$inlined;
    final /* synthetic */ ContextAware $this_withContextAvailable$inlined;

    public C0049x8a9e0a55(C12498k kVar, ContextAware contextAware, C12276b bVar) {
        this.$co = kVar;
        this.$this_withContextAvailable$inlined = contextAware;
        this.$onContextAvailable$inlined = bVar;
    }

    public void onContextAvailable(Context context) {
        Object obj;
        C12318m.m42360d(context, C11319d.f32574R);
        C12498k kVar = this.$co;
        try {
            C12332o.C12333a aVar = C12332o.f34096a;
            C0049x8a9e0a55 contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 = this;
            obj = C12332o.m42396f(this.$onContextAvailable$inlined.invoke(context));
        } catch (Throwable th) {
            C12332o.C12333a aVar2 = C12332o.f34096a;
            obj = C12332o.m42396f(C12335p.m42398a(th));
        }
        kVar.resumeWith(obj);
    }
}
