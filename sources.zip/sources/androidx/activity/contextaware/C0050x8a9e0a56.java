package androidx.activity.contextaware;

import kotlin.C12340u;
import kotlin.Metadata;
import kotlin.jvm.internal.C12319n;
import kotlin.jvm.p580a.C12276b;

@Metadata(mo62563bv = {1, 0, 3}, mo62564d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\n¢\u0006\u0002\b\u0005¨\u0006\u0006"}, mo62565d2 = {"<anonymous>", "", "R", "it", "", "invoke", "androidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$1"}, mo62566k = 3, mo62567mv = {1, 4, 1})
/* renamed from: androidx.activity.contextaware.ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$2 */
/* compiled from: ContextAware.kt */
public final class C0050x8a9e0a56 extends C12319n implements C12276b<Throwable, C12340u> {
    final /* synthetic */ C0049x8a9e0a55 $listener;
    final /* synthetic */ C12276b $onContextAvailable$inlined;
    final /* synthetic */ ContextAware $this_withContextAvailable$inlined;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0050x8a9e0a56(C0049x8a9e0a55 contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1, ContextAware contextAware, C12276b bVar) {
        super(1);
        this.$listener = contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1;
        this.$this_withContextAvailable$inlined = contextAware;
        this.$onContextAvailable$inlined = bVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((Throwable) obj);
        return C12340u.f34103a;
    }

    public final void invoke(Throwable th) {
        this.$this_withContextAvailable$inlined.removeOnContextAvailableListener(this.$listener);
    }
}
