package androidx.activity.contextaware;

import android.content.Context;
import kotlin.Metadata;
import kotlin.coroutines.C12172d;
import kotlin.coroutines.jvm.internal.C12189f;
import kotlin.coroutines.p573a.C12161b;
import kotlin.jvm.internal.C12317l;
import kotlin.jvm.p580a.C12276b;
import kotlinx.coroutines.C12498k;
import kotlinx.coroutines.C12499l;

@Metadata(mo62563bv = {1, 0, 3}, mo62564d1 = {"\u0000\u0016\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a1\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\u00020\u00022\u0014\b\u0004\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u0002H\u00010\u0004HHø\u0001\u0000¢\u0006\u0002\u0010\u0006\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007"}, mo62565d2 = {"withContextAvailable", "R", "Landroidx/activity/contextaware/ContextAware;", "onContextAvailable", "Lkotlin/Function1;", "Landroid/content/Context;", "(Landroidx/activity/contextaware/ContextAware;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "activity-ktx_release"}, mo62566k = 2, mo62567mv = {1, 4, 1})
/* compiled from: ContextAware.kt */
public final class ContextAwareKt {
    public static final <R> Object withContextAvailable(ContextAware contextAware, C12276b<? super Context, ? extends R> bVar, C12172d<? super R> dVar) {
        Context peekAvailableContext = contextAware.peekAvailableContext();
        if (peekAvailableContext != null) {
            return bVar.invoke(peekAvailableContext);
        }
        C12499l lVar = new C12499l(C12161b.m42171a(dVar), 1);
        lVar.mo63176c();
        C12498k kVar = lVar;
        C0049x8a9e0a55 contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 = new C0049x8a9e0a55(kVar, contextAware, bVar);
        contextAware.addOnContextAvailableListener(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1);
        kVar.mo63169a(new C0050x8a9e0a56(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1, contextAware, bVar));
        Object e = lVar.mo63177e();
        if (e != C12161b.m42173a()) {
            return e;
        }
        C12189f.m42204c(dVar);
        return e;
    }

    private static final Object withContextAvailable$$forInline(ContextAware contextAware, C12276b bVar, C12172d dVar) {
        Context peekAvailableContext = contextAware.peekAvailableContext();
        if (peekAvailableContext != null) {
            return bVar.invoke(peekAvailableContext);
        }
        C12317l.m42342a(0);
        C12499l lVar = new C12499l(C12161b.m42171a(dVar), 1);
        lVar.mo63176c();
        C12498k kVar = lVar;
        C0049x8a9e0a55 contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 = new C0049x8a9e0a55(kVar, contextAware, bVar);
        contextAware.addOnContextAvailableListener(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1);
        kVar.mo63169a(new C0050x8a9e0a56(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1, contextAware, bVar));
        Object e = lVar.mo63177e();
        if (e == C12161b.m42173a()) {
            C12189f.m42204c(dVar);
        }
        C12317l.m42342a(1);
        return e;
    }
}
