package androidx.activity.result;

public interface ActivityResultCallback<O> {
    void onActivityResult(O o);
}
