package androidx.activity.result;

import kotlin.Metadata;
import kotlin.jvm.p580a.C12276b;

@Metadata(mo62563bv = {1, 0, 3}, mo62564d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032\u000e\u0010\u0004\u001a\n \u0005*\u0004\u0018\u0001H\u0003H\u0003H\n¢\u0006\u0004\b\u0006\u0010\u0007"}, mo62565d2 = {"<anonymous>", "", "I", "O", "it", "kotlin.jvm.PlatformType", "onActivityResult", "(Ljava/lang/Object;)V"}, mo62566k = 3, mo62567mv = {1, 4, 1})
/* renamed from: androidx.activity.result.ActivityResultCallerKt$registerForActivityResult$resultLauncher$1 */
/* compiled from: ActivityResultCaller.kt */
final class C0055xec7aa640<O> implements ActivityResultCallback<O> {
    final /* synthetic */ C12276b $callback;

    C0055xec7aa640(C12276b bVar) {
        this.$callback = bVar;
    }

    public final void onActivityResult(O o) {
        this.$callback.invoke(o);
    }
}
