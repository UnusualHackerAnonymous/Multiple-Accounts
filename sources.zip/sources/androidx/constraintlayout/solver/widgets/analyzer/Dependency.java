package androidx.constraintlayout.solver.widgets.analyzer;

public interface Dependency {
    void update(Dependency dependency);
}
