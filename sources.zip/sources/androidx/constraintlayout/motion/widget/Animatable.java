package androidx.constraintlayout.motion.widget;

public interface Animatable {
    float getProgress();

    void setProgress(float f);
}
