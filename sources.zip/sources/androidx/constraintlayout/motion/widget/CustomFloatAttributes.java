package androidx.constraintlayout.motion.widget;

public interface CustomFloatAttributes {
    float get(String str);

    String[] getListOfAttributes();

    void set(String str, float f);
}
