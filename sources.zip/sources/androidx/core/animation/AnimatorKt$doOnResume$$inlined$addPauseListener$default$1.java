package androidx.core.animation;

import android.animation.Animator;
import kotlin.Metadata;
import kotlin.jvm.internal.C12318m;
import kotlin.jvm.p580a.C12276b;

@Metadata(mo62564d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0007¸\u0006\u0000"}, mo62565d2 = {"androidx/core/animation/AnimatorKt$addPauseListener$listener$1", "Landroid/animation/Animator$AnimatorPauseListener;", "onAnimationPause", "", "animator", "Landroid/animation/Animator;", "onAnimationResume", "core-ktx_release"}, mo62566k = 1, mo62567mv = {1, 5, 1}, mo62569xi = 48)
/* compiled from: Animator.kt */
public final class AnimatorKt$doOnResume$$inlined$addPauseListener$default$1 implements Animator.AnimatorPauseListener {
    final /* synthetic */ C12276b $onResume;

    public void onAnimationPause(Animator animator) {
        C12318m.m42360d(animator, "animator");
    }

    public AnimatorKt$doOnResume$$inlined$addPauseListener$default$1(C12276b bVar) {
        this.$onResume = bVar;
    }

    public void onAnimationResume(Animator animator) {
        C12318m.m42360d(animator, "animator");
        this.$onResume.invoke(animator);
    }
}
