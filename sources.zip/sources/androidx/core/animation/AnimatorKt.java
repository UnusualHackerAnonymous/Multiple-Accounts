package androidx.core.animation;

import android.animation.Animator;
import kotlin.C12340u;
import kotlin.Metadata;
import kotlin.jvm.internal.C12318m;
import kotlin.jvm.p580a.C12276b;

@Metadata(mo62564d1 = {"\u0000(\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\n\u001a¤\u0001\u0010\u0000\u001a\u00020\u0001*\u00020\u00022#\b\u0006\u0010\u0003\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\t\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\n\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\u000b\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u001aZ\u0010\f\u001a\u00020\r*\u00020\u00022#\b\u0006\u0010\u000e\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\u000f\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u001a5\u0010\u0010\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u001a5\u0010\u0012\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u001a5\u0010\u0013\u001a\u00020\r*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u001a5\u0010\u0014\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u001a5\u0010\u0015\u001a\u00020\r*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u001a5\u0010\u0016\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\bø\u0001\u0000\u0002\u0007\n\u0005\b20\u0001¨\u0006\u0017"}, mo62565d2 = {"addListener", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "onEnd", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "animator", "", "onStart", "onCancel", "onRepeat", "addPauseListener", "Landroid/animation/Animator$AnimatorPauseListener;", "onResume", "onPause", "doOnCancel", "action", "doOnEnd", "doOnPause", "doOnRepeat", "doOnResume", "doOnStart", "core-ktx_release"}, mo62566k = 2, mo62567mv = {1, 5, 1}, mo62569xi = 48)
/* compiled from: Animator.kt */
public final class AnimatorKt {
    public static /* synthetic */ Animator.AnimatorListener addListener$default(Animator animator, C12276b bVar, C12276b bVar2, C12276b bVar3, C12276b bVar4, int i, Object obj) {
        if ((i & 1) != 0) {
            bVar = AnimatorKt$addListener$1.INSTANCE;
        }
        if ((i & 2) != 0) {
            bVar2 = AnimatorKt$addListener$2.INSTANCE;
        }
        if ((i & 4) != 0) {
            bVar3 = AnimatorKt$addListener$3.INSTANCE;
        }
        if ((i & 8) != 0) {
            bVar4 = AnimatorKt$addListener$4.INSTANCE;
        }
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "onEnd");
        C12318m.m42360d(bVar2, "onStart");
        C12318m.m42360d(bVar3, "onCancel");
        C12318m.m42360d(bVar4, "onRepeat");
        Animator.AnimatorListener animatorKt$addListener$listener$1 = new AnimatorKt$addListener$listener$1(bVar4, bVar, bVar3, bVar2);
        animator.addListener(animatorKt$addListener$listener$1);
        return animatorKt$addListener$listener$1;
    }

    public static final Animator.AnimatorListener addListener(Animator animator, C12276b<? super Animator, C12340u> bVar, C12276b<? super Animator, C12340u> bVar2, C12276b<? super Animator, C12340u> bVar3, C12276b<? super Animator, C12340u> bVar4) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "onEnd");
        C12318m.m42360d(bVar2, "onStart");
        C12318m.m42360d(bVar3, "onCancel");
        C12318m.m42360d(bVar4, "onRepeat");
        Animator.AnimatorListener animatorKt$addListener$listener$1 = new AnimatorKt$addListener$listener$1(bVar4, bVar, bVar3, bVar2);
        animator.addListener(animatorKt$addListener$listener$1);
        return animatorKt$addListener$listener$1;
    }

    public static /* synthetic */ Animator.AnimatorPauseListener addPauseListener$default(Animator animator, C12276b bVar, C12276b bVar2, int i, Object obj) {
        if ((i & 1) != 0) {
            bVar = AnimatorKt$addPauseListener$1.INSTANCE;
        }
        if ((i & 2) != 0) {
            bVar2 = AnimatorKt$addPauseListener$2.INSTANCE;
        }
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "onResume");
        C12318m.m42360d(bVar2, "onPause");
        Animator.AnimatorPauseListener animatorKt$addPauseListener$listener$1 = new AnimatorKt$addPauseListener$listener$1(bVar2, bVar);
        animator.addPauseListener(animatorKt$addPauseListener$listener$1);
        return animatorKt$addPauseListener$listener$1;
    }

    public static final Animator.AnimatorPauseListener addPauseListener(Animator animator, C12276b<? super Animator, C12340u> bVar, C12276b<? super Animator, C12340u> bVar2) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "onResume");
        C12318m.m42360d(bVar2, "onPause");
        Animator.AnimatorPauseListener animatorKt$addPauseListener$listener$1 = new AnimatorKt$addPauseListener$listener$1(bVar2, bVar);
        animator.addPauseListener(animatorKt$addPauseListener$listener$1);
        return animatorKt$addPauseListener$listener$1;
    }

    public static final Animator.AnimatorListener doOnEnd(Animator animator, C12276b<? super Animator, C12340u> bVar) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "action");
        Animator.AnimatorListener animatorKt$doOnEnd$$inlined$addListener$default$1 = new AnimatorKt$doOnEnd$$inlined$addListener$default$1(bVar);
        animator.addListener(animatorKt$doOnEnd$$inlined$addListener$default$1);
        return animatorKt$doOnEnd$$inlined$addListener$default$1;
    }

    public static final Animator.AnimatorListener doOnStart(Animator animator, C12276b<? super Animator, C12340u> bVar) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "action");
        Animator.AnimatorListener animatorKt$doOnStart$$inlined$addListener$default$1 = new AnimatorKt$doOnStart$$inlined$addListener$default$1(bVar);
        animator.addListener(animatorKt$doOnStart$$inlined$addListener$default$1);
        return animatorKt$doOnStart$$inlined$addListener$default$1;
    }

    public static final Animator.AnimatorListener doOnCancel(Animator animator, C12276b<? super Animator, C12340u> bVar) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "action");
        Animator.AnimatorListener animatorKt$doOnCancel$$inlined$addListener$default$1 = new AnimatorKt$doOnCancel$$inlined$addListener$default$1(bVar);
        animator.addListener(animatorKt$doOnCancel$$inlined$addListener$default$1);
        return animatorKt$doOnCancel$$inlined$addListener$default$1;
    }

    public static final Animator.AnimatorListener doOnRepeat(Animator animator, C12276b<? super Animator, C12340u> bVar) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "action");
        Animator.AnimatorListener animatorKt$doOnRepeat$$inlined$addListener$default$1 = new AnimatorKt$doOnRepeat$$inlined$addListener$default$1(bVar);
        animator.addListener(animatorKt$doOnRepeat$$inlined$addListener$default$1);
        return animatorKt$doOnRepeat$$inlined$addListener$default$1;
    }

    public static final Animator.AnimatorPauseListener doOnResume(Animator animator, C12276b<? super Animator, C12340u> bVar) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "action");
        Animator.AnimatorPauseListener animatorKt$doOnResume$$inlined$addPauseListener$default$1 = new AnimatorKt$doOnResume$$inlined$addPauseListener$default$1(bVar);
        animator.addPauseListener(animatorKt$doOnResume$$inlined$addPauseListener$default$1);
        return animatorKt$doOnResume$$inlined$addPauseListener$default$1;
    }

    public static final Animator.AnimatorPauseListener doOnPause(Animator animator, C12276b<? super Animator, C12340u> bVar) {
        C12318m.m42360d(animator, "<this>");
        C12318m.m42360d(bVar, "action");
        Animator.AnimatorPauseListener animatorKt$doOnPause$$inlined$addPauseListener$default$1 = new AnimatorKt$doOnPause$$inlined$addPauseListener$default$1(bVar);
        animator.addPauseListener(animatorKt$doOnPause$$inlined$addPauseListener$default$1);
        return animatorKt$doOnPause$$inlined$addPauseListener$default$1;
    }
}
