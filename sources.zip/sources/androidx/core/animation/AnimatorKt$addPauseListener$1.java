package androidx.core.animation;

import android.animation.Animator;
import kotlin.C12340u;
import kotlin.Metadata;
import kotlin.jvm.internal.C12318m;
import kotlin.jvm.internal.C12319n;
import kotlin.jvm.p580a.C12276b;

@Metadata(mo62564d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, mo62565d2 = {"<anonymous>", "", "it", "Landroid/animation/Animator;"}, mo62566k = 3, mo62567mv = {1, 5, 1}, mo62569xi = 48)
/* compiled from: Animator.kt */
public final class AnimatorKt$addPauseListener$1 extends C12319n implements C12276b<Animator, C12340u> {
    public static final AnimatorKt$addPauseListener$1 INSTANCE = new AnimatorKt$addPauseListener$1();

    public AnimatorKt$addPauseListener$1() {
        super(1);
    }

    public final void invoke(Animator animator) {
        C12318m.m42360d(animator, "it");
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((Animator) obj);
        return C12340u.f34103a;
    }
}
