package androidx.appcompat.resources;

import com.excelliance.multiaccounts.R;

/* renamed from: androidx.appcompat.resources.R */
public final class C0097R {

    /* renamed from: androidx.appcompat.resources.R$attr */
    public static final class attr {
        public static final int alpha = 2130968660;
        public static final int font = 2130968977;
        public static final int fontProviderAuthority = 2130968979;
        public static final int fontProviderCerts = 2130968980;
        public static final int fontProviderFetchStrategy = 2130968981;
        public static final int fontProviderFetchTimeout = 2130968982;
        public static final int fontProviderPackage = 2130968983;
        public static final int fontProviderQuery = 2130968984;
        public static final int fontStyle = 2130968986;
        public static final int fontVariationSettings = 2130968987;
        public static final int fontWeight = 2130968988;
        public static final int ttcIndex = 2130969486;

        private attr() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$color */
    public static final class color {
        public static final int notification_action_color_filter = 2131100083;
        public static final int notification_icon_bg_color = 2131100084;
        public static final int ripple_material_light = 2131100133;
        public static final int secondary_text_default_material_light = 2131100136;

        private color() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$dimen */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131165399;
        public static final int compat_button_inset_vertical_material = 2131165400;
        public static final int compat_button_padding_horizontal_material = 2131165401;
        public static final int compat_button_padding_vertical_material = 2131165402;
        public static final int compat_control_corner_material = 2131165403;
        public static final int compat_notification_large_icon_max_height = 2131165404;
        public static final int compat_notification_large_icon_max_width = 2131165405;
        public static final int notification_action_icon_size = 2131167035;
        public static final int notification_action_text_size = 2131167036;
        public static final int notification_big_circle_margin = 2131167037;
        public static final int notification_content_margin_start = 2131167038;
        public static final int notification_large_icon_height = 2131167039;
        public static final int notification_large_icon_width = 2131167040;
        public static final int notification_main_column_padding_top = 2131167041;
        public static final int notification_media_narrow_margin = 2131167042;
        public static final int notification_right_icon_size = 2131167043;
        public static final int notification_right_side_padding_top = 2131167044;
        public static final int notification_small_icon_background_padding = 2131167045;
        public static final int notification_small_icon_size_as_large = 2131167046;
        public static final int notification_subtext_size = 2131167047;
        public static final int notification_top_pad = 2131167048;
        public static final int notification_top_pad_large_text = 2131167049;

        private dimen() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$drawable */
    public static final class C0098drawable {
        public static final int abc_vector_test = 2131230826;
        public static final int notification_action_background = 2131231448;
        public static final int notification_bg = 2131231449;
        public static final int notification_bg_low = 2131231450;
        public static final int notification_bg_low_normal = 2131231451;
        public static final int notification_bg_low_pressed = 2131231452;
        public static final int notification_bg_normal = 2131231453;
        public static final int notification_bg_normal_pressed = 2131231454;
        public static final int notification_icon_background = 2131231455;
        public static final int notification_template_icon_bg = 2131231457;
        public static final int notification_template_icon_low_bg = 2131231458;
        public static final int notification_tile_bg = 2131231459;
        public static final int notify_panel_notification_icon_bg = 2131231460;

        private C0098drawable() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$id */
    public static final class C0099id {
        public static final int accessibility_action_clickable_span = 2131361809;
        public static final int accessibility_custom_action_0 = 2131361810;
        public static final int accessibility_custom_action_1 = 2131361811;
        public static final int accessibility_custom_action_10 = 2131361812;
        public static final int accessibility_custom_action_11 = 2131361813;
        public static final int accessibility_custom_action_12 = 2131361814;
        public static final int accessibility_custom_action_13 = 2131361815;
        public static final int accessibility_custom_action_14 = 2131361816;
        public static final int accessibility_custom_action_15 = 2131361817;
        public static final int accessibility_custom_action_16 = 2131361818;
        public static final int accessibility_custom_action_17 = 2131361819;
        public static final int accessibility_custom_action_18 = 2131361820;
        public static final int accessibility_custom_action_19 = 2131361821;
        public static final int accessibility_custom_action_2 = 2131361822;
        public static final int accessibility_custom_action_20 = 2131361823;
        public static final int accessibility_custom_action_21 = 2131361824;
        public static final int accessibility_custom_action_22 = 2131361825;
        public static final int accessibility_custom_action_23 = 2131361826;
        public static final int accessibility_custom_action_24 = 2131361827;
        public static final int accessibility_custom_action_25 = 2131361828;
        public static final int accessibility_custom_action_26 = 2131361829;
        public static final int accessibility_custom_action_27 = 2131361830;
        public static final int accessibility_custom_action_28 = 2131361831;
        public static final int accessibility_custom_action_29 = 2131361832;
        public static final int accessibility_custom_action_3 = 2131361833;
        public static final int accessibility_custom_action_30 = 2131361834;
        public static final int accessibility_custom_action_31 = 2131361835;
        public static final int accessibility_custom_action_4 = 2131361836;
        public static final int accessibility_custom_action_5 = 2131361837;
        public static final int accessibility_custom_action_6 = 2131361838;
        public static final int accessibility_custom_action_7 = 2131361839;
        public static final int accessibility_custom_action_8 = 2131361840;
        public static final int accessibility_custom_action_9 = 2131361841;
        public static final int action_container = 2131361852;
        public static final int action_divider = 2131361854;
        public static final int action_image = 2131361855;
        public static final int action_text = 2131361862;
        public static final int actions = 2131361863;
        public static final int async = 2131362004;
        public static final int blocking = 2131362026;
        public static final int chronometer = 2131362097;
        public static final int dialog_button = 2131362141;
        public static final int forever = 2131362236;
        public static final int icon = 2131362306;
        public static final int icon_group = 2131362309;
        public static final int info = 2131362324;
        public static final int italic = 2131362335;
        public static final int line1 = 2131362459;
        public static final int line3 = 2131362460;
        public static final int normal = 2131362762;
        public static final int notification_background = 2131362763;
        public static final int notification_main_column = 2131362764;
        public static final int notification_main_column_container = 2131362765;
        public static final int right_icon = 2131362914;
        public static final int right_side = 2131362915;
        public static final int tag_accessibility_actions = 2131363106;
        public static final int tag_accessibility_clickable_spans = 2131363107;
        public static final int tag_accessibility_heading = 2131363108;
        public static final int tag_accessibility_pane_title = 2131363109;
        public static final int tag_screen_reader_focusable = 2131363113;
        public static final int tag_transition_group = 2131363115;
        public static final int tag_unhandled_key_event_manager = 2131363116;
        public static final int tag_unhandled_key_listeners = 2131363117;
        public static final int text = 2131363131;
        public static final int text2 = 2131363133;
        public static final int time = 2131363151;
        public static final int title = 2131363152;

        private C0099id() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$integer */
    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131427356;

        private integer() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$layout */
    public static final class layout {
        public static final int custom_dialog = 2131558490;
        public static final int notification_action = 2131558692;
        public static final int notification_action_tombstone = 2131558693;
        public static final int notification_template_custom_big = 2131558700;
        public static final int notification_template_icon_group = 2131558701;
        public static final int notification_template_part_chronometer = 2131558705;
        public static final int notification_template_part_time = 2131558706;

        private layout() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$string */
    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131821339;

        private string() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$style */
    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131886483;
        public static final int TextAppearance_Compat_Notification_Info = 2131886484;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131886486;
        public static final int TextAppearance_Compat_Notification_Time = 2131886489;
        public static final int TextAppearance_Compat_Notification_Title = 2131886491;
        public static final int Widget_Compat_NotificationActionContainer = 2131886729;
        public static final int Widget_Compat_NotificationActionText = 2131886730;

        private style() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$styleable */
    public static final class styleable {
        public static final int[] AnimatedStateListDrawableCompat = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
        public static final int AnimatedStateListDrawableCompat_android_dither = 0;
        public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
        public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
        public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
        public static final int AnimatedStateListDrawableCompat_android_visible = 1;
        public static final int[] AnimatedStateListDrawableItem = {16842960, 16843161};
        public static final int AnimatedStateListDrawableItem_android_drawable = 1;
        public static final int AnimatedStateListDrawableItem_android_id = 0;
        public static final int[] AnimatedStateListDrawableTransition = {16843161, 16843849, 16843850, 16843851};
        public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
        public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
        public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
        public static final int AnimatedStateListDrawableTransition_android_toId = 1;
        public static final int[] ColorStateListItem = {16843173, 16843551, R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int FontFamily_fontProviderSystemFontFamily = 6;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] StateListDrawable = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int[] StateListDrawableItem = {16843161};
        public static final int StateListDrawableItem_android_drawable = 0;
        public static final int StateListDrawable_android_constantSize = 3;
        public static final int StateListDrawable_android_dither = 0;
        public static final int StateListDrawable_android_enterFadeDuration = 4;
        public static final int StateListDrawable_android_exitFadeDuration = 5;
        public static final int StateListDrawable_android_variablePadding = 2;
        public static final int StateListDrawable_android_visible = 1;

        private styleable() {
        }
    }

    private C0097R() {
    }
}
