package androidx.appcompat.view;

@Deprecated
public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
