package androidx.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Metadata;
import kotlin.annotation.C12140a;
import kotlin.annotation.C12141b;
import kotlin.annotation.Retention;

@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
@kotlin.annotation.Target(allowedTargets = {C12141b.ANNOTATION_CLASS, C12141b.CLASS, C12141b.FUNCTION, C12141b.PROPERTY_GETTER, C12141b.PROPERTY_SETTER, C12141b.VALUE_PARAMETER, C12141b.FIELD})
@Metadata(mo62564d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0000¨\u0006\u0002"}, mo62565d2 = {"Landroidx/annotation/NonUiContext;", "", "annotation"}, mo62566k = 1, mo62567mv = {1, 7, 1}, mo62569xi = 48)
@Retention(C12140a.SOURCE)
@java.lang.annotation.Retention(RetentionPolicy.SOURCE)
/* compiled from: NonUiContext.kt */
public @interface NonUiContext {
}
