package androidx.annotation.experimental;

/* renamed from: androidx.annotation.experimental.R */
public final class C0063R {
    private C0063R() {
    }
}
