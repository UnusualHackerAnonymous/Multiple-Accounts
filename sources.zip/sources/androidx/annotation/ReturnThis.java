package androidx.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;
import kotlin.Metadata;
import kotlin.annotation.C12140a;
import kotlin.annotation.C12141b;
import kotlin.annotation.MustBeDocumented;
import kotlin.annotation.Retention;
import kotlin.annotation.Target;

@MustBeDocumented
@Target(allowedTargets = {C12141b.FUNCTION, C12141b.CLASS})
@Retention(C12140a.BINARY)
@Documented
@java.lang.annotation.Target({ElementType.TYPE, ElementType.METHOD})
@Metadata(mo62564d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0000¨\u0006\u0002"}, mo62565d2 = {"Landroidx/annotation/ReturnThis;", "", "annotation"}, mo62566k = 1, mo62567mv = {1, 7, 1}, mo62569xi = 48)
@java.lang.annotation.Retention(RetentionPolicy.CLASS)
/* compiled from: ReturnThis.kt */
public @interface ReturnThis {
}
